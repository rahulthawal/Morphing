To run the code user need to provide parameter such as source file, target file, dimension,...etc
for example

morph('taylor.jpg','fox.jpg',[480 640],  1, 1, 0.75, 'savefile', 0, 0); 
